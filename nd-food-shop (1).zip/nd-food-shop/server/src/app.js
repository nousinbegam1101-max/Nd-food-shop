import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import mongoose from 'mongoose';
import authRoutes from './routes/authRoutes.js';
import foodRoutes from './routes/foodRoutes.js';
import categoryRoutes from './routes/categoryRoutes.js';
import orderRoutes from './routes/orderRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import contactRoutes from './routes/contactRoutes.js';
import { notFound, errorHandler } from './middleware/error.js';

const app = express();
const clientUrl = () => process.env.CLIENT_URL || 'http://localhost:5173';

app.use(helmet());
app.use(cors({ origin: (o, cb) => cb(null, !o || o === clientUrl()), credentials: true }));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
if (process.env.NODE_ENV !== 'test') app.use(morgan('dev'));

// CSRF defence for cookie auth: state-changing requests must come from our client origin.
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin && origin !== clientUrl())
    return res.status(403).json({ success: false, message: 'Cross-origin request blocked' });
  next();
});

// Graceful behaviour when MongoDB is down.
app.use('/api', (req, res, next) =>
  mongoose.connection.readyState === 1 || req.path === '/health'
    ? next()
    : res.status(503).json({ success: false, message: 'Database unavailable. Please try again shortly.' }));

app.get('/api/health', (_req, res) => res.json({ success: true, db: mongoose.connection.readyState === 1 }));
app.use('/api/auth', authRoutes);
app.use('/api/foods', foodRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/contact', contactRoutes);

app.use(notFound);
app.use(errorHandler);
export default app;
