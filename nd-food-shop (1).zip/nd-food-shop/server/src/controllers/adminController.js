import User from '../models/User.js';
import Food from '../models/Food.js';
import Order from '../models/Order.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const dashboard = asyncHandler(async (_req, res) => {
  const since = new Date(Date.now() - 7 * 86400000);
  const [orders, customers, foods, revenue, byStatus, recent, sales] = await Promise.all([
    Order.countDocuments(), User.countDocuments({ role: 'customer' }), Food.countDocuments(),
    Order.aggregate([{ $match: { orderStatus: 'Delivered' } }, { $group: { _id: null, total: { $sum: '$totalAmount' } } }]),
    Order.aggregate([{ $group: { _id: '$orderStatus', count: { $sum: 1 } } }]),
    Order.find().sort('-createdAt').limit(5).populate('customer', 'name'),
    Order.aggregate([
      { $match: { createdAt: { $gte: since }, orderStatus: { $ne: 'Cancelled' } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, total: { $sum: '$totalAmount' }, orders: { $sum: 1 } } },
      { $sort: { _id: 1 } },
    ]),
  ]);
  res.json({ success: true, data: {
    totalOrders: orders, totalCustomers: customers, totalFoods: foods, totalRevenue: revenue[0]?.total || 0,
    statusSummary: Object.fromEntries(byStatus.map((s) => [s._id, s.count])), recentOrders: recent, salesLast7Days: sales,
  } });
});

export const listCustomers = asyncHandler(async (req, res) => {
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit) || 10, 100);
  const filter = { role: 'customer' };
  if (req.query.q) { const r = new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); filter.$or = [{ name: r }, { email: r }]; }
  const [data, total] = await Promise.all([
    User.find(filter).sort('-createdAt').skip((page - 1) * limit).limit(limit), // passwordHash is select:false
    User.countDocuments(filter),
  ]);
  res.json({ success: true, data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

export const customerOrders = asyncHandler(async (req, res) =>
  res.json({ success: true, data: await Order.find({ customer: req.params.id }).sort('-createdAt').limit(100) }));
