import User from '../models/User.js';
import { ApiError, asyncHandler } from '../utils/asyncHandler.js';
import { sendToken, clearToken } from '../utils/token.js';

export const register = asyncHandler(async (req, res) => {
  const { name, email, phone, password } = req.body; // role deliberately ignored
  if (await User.findOne({ email })) throw new ApiError(409, 'Email is already registered');
  const user = await User.create({
    name, email, phone, passwordHash: await User.hashPassword(password), role: 'customer',
  });
  sendToken(res, user);
  res.status(201).json({ success: true, data: user });
});

export const login = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email }).select('+passwordHash');
  if (!user || !(await user.comparePassword(req.body.password)))
    throw new ApiError(401, 'Invalid email or password');
  sendToken(res, user);
  res.json({ success: true, data: user });
});

export const me = (req, res) => res.json({ success: true, data: req.user });

export const logout = (_req, res) => {
  clearToken(res);
  res.json({ success: true, message: 'Logged out' });
};

export const updateProfile = asyncHandler(async (req, res) => {
  const { name, phone, address } = req.body;
  if (name !== undefined) req.user.name = name;
  if (phone !== undefined) req.user.phone = phone;
  if (address) req.user.address = { line1: address.line1, city: address.city, postalCode: address.postalCode };
  await req.user.save();
  res.json({ success: true, data: req.user });
});

export const changePassword = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('+passwordHash');
  if (!(await user.comparePassword(req.body.currentPassword))) throw new ApiError(400, 'Current password is incorrect');
  user.passwordHash = await User.hashPassword(req.body.newPassword);
  await user.save();
  res.json({ success: true, message: 'Password updated' });
});
