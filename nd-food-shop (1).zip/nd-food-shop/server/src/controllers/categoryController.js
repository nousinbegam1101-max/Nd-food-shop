import Category from '../models/Category.js';
import Food from '../models/Food.js';
import { ApiError, asyncHandler } from '../utils/asyncHandler.js';

const pick = (b) => ({ name: b.name, description: b.description, image: b.image });

export const listCategories = asyncHandler(async (_req, res) =>
  res.json({ success: true, data: await Category.find().sort('name') }));
export const createCategory = asyncHandler(async (req, res) =>
  res.status(201).json({ success: true, data: await Category.create(pick(req.body)) }));
export const updateCategory = asyncHandler(async (req, res) => {
  const c = await Category.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!c) throw new ApiError(404, 'Category not found');
  res.json({ success: true, data: c });
});
export const deleteCategory = asyncHandler(async (req, res) => {
  const used = await Food.countDocuments({ category: req.params.id });
  if (used) throw new ApiError(409, `Cannot delete: ${used} food item(s) use this category`);
  if (!(await Category.findByIdAndDelete(req.params.id))) throw new ApiError(404, 'Category not found');
  res.json({ success: true, message: 'Category deleted' });
});
