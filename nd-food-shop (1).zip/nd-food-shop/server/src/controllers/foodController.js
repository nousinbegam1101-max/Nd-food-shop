import Food from '../models/Food.js';
import Category from '../models/Category.js';
import { ApiError, asyncHandler } from '../utils/asyncHandler.js';

const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const pick = (b) => ['name', 'description', 'price', 'image', 'category', 'isVegetarian', 'isAvailable', 'isPopular']
  .reduce((o, k) => (b[k] !== undefined ? { ...o, [k]: b[k] } : o), {});

export const listFoods = asyncHandler(async (req, res) => {
  const { q, category, veg, popular, sort } = req.query;
  const page = Math.max(parseInt(req.query.page) || 1, 1);
  const limit = Math.min(parseInt(req.query.limit) || 12, 100);
  const filter = {};
  if (q) filter.name = { $regex: esc(String(q)), $options: 'i' };
  if (category) filter.category = category;
  if (veg === 'true' || veg === 'false') filter.isVegetarian = veg === 'true';
  if (popular === 'true') filter.isPopular = true;
  const order = sort === 'price_asc' ? { price: 1 } : sort === 'price_desc' ? { price: -1 } : { createdAt: -1 };
  const [data, total] = await Promise.all([
    Food.find(filter).populate('category', 'name').sort(order).skip((page - 1) * limit).limit(limit),
    Food.countDocuments(filter),
  ]);
  res.json({ success: true, data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

export const getFood = asyncHandler(async (req, res) => {
  const food = await Food.findById(req.params.id).populate('category', 'name');
  if (!food) throw new ApiError(404, 'Food item not found');
  res.json({ success: true, data: food });
});

export const createFood = asyncHandler(async (req, res) => {
  if (!(await Category.exists({ _id: req.body.category }))) throw new ApiError(400, 'Category does not exist');
  res.status(201).json({ success: true, data: await Food.create(pick(req.body)) });
});

export const updateFood = asyncHandler(async (req, res) => {
  if (req.body.category && !(await Category.exists({ _id: req.body.category }))) throw new ApiError(400, 'Category does not exist');
  const food = await Food.findByIdAndUpdate(req.params.id, pick(req.body), { new: true, runValidators: true });
  if (!food) throw new ApiError(404, 'Food item not found');
  res.json({ success: true, data: food });
});

export const deleteFood = asyncHandler(async (req, res) => {
  if (!(await Food.findByIdAndDelete(req.params.id))) throw new ApiError(404, 'Food item not found');
  res.json({ success: true, message: 'Food item deleted' });
});
