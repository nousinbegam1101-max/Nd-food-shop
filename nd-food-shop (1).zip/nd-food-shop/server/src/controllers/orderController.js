import Food from '../models/Food.js';
import Order, { STATUS_TRANSITIONS, CUSTOMER_CANCELLABLE, ORDER_STATUSES } from '../models/Order.js';
import { ApiError, asyncHandler } from '../utils/asyncHandler.js';

const paging = (q) => {
  const page = Math.max(parseInt(q.page) || 1, 1);
  const limit = Math.min(parseInt(q.limit) || 10, 100);
  return { page, limit, skip: (page - 1) * limit };
};

export const createOrder = asyncHandler(async (req, res) => {
  const { items, deliveryAddress, phone, deliveryInstructions } = req.body;
  const ids = items.map((i) => i.food);
  if (new Set(ids).size !== ids.length) throw new ApiError(400, 'Duplicate items in order');
  const foods = await Food.find({ _id: { $in: ids } });
  const byId = new Map(foods.map((f) => [String(f._id), f]));
  const lines = items.map(({ food, quantity }) => {
    const f = byId.get(String(food));
    if (!f) throw new ApiError(400, 'An ordered item no longer exists');
    if (!f.isAvailable) throw new ApiError(400, `${f.name} is currently unavailable`);
    return { food: f._id, name: f.name, price: f.price, image: f.image, quantity }; // trusted DB price
  });
  const subtotal = lines.reduce((s, l) => s + l.price * l.quantity, 0);
  const fee = Number(process.env.DELIVERY_FEE ?? 40);
  const freeAbove = Number(process.env.FREE_DELIVERY_ABOVE ?? 500);
  const deliveryFee = subtotal >= freeAbove ? 0 : fee;
  const order = await Order.create({
    customer: req.user._id, customerName: req.user.name, items: lines, deliveryAddress, phone,
    subtotal, deliveryFee, totalAmount: subtotal + deliveryFee, paymentMethod: 'COD',
    deliveryInstructions, statusHistory: [{ status: 'Pending' }],
  });
  res.status(201).json({ success: true, data: order });
});

export const myOrders = asyncHandler(async (req, res) => {
  const { page, limit, skip } = paging(req.query);
  const filter = { customer: req.user._id };
  const [data, total] = await Promise.all([Order.find(filter).sort('-createdAt').skip(skip).limit(limit), Order.countDocuments(filter)]);
  res.json({ success: true, data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

export const getOrder = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  // 404 (not 403) for other people's orders so IDs cannot be probed
  if (!order || (req.user.role !== 'admin' && String(order.customer) !== String(req.user._id)))
    throw new ApiError(404, 'Order not found');
  res.json({ success: true, data: order });
});

export const cancelOrder = asyncHandler(async (req, res) => {
  const order = await Order.findOne({ _id: req.params.id, customer: req.user._id });
  if (!order) throw new ApiError(404, 'Order not found');
  if (!CUSTOMER_CANCELLABLE.includes(order.orderStatus))
    throw new ApiError(400, `Orders that are "${order.orderStatus}" can no longer be cancelled`);
  order.orderStatus = 'Cancelled';
  order.statusHistory.push({ status: 'Cancelled' });
  await order.save();
  res.json({ success: true, data: order });
});

export const adminListOrders = asyncHandler(async (req, res) => {
  const { page, limit, skip } = paging(req.query);
  const filter = {};
  if (ORDER_STATUSES.includes(req.query.status)) filter.orderStatus = req.query.status;
  const [data, total] = await Promise.all([
    Order.find(filter).populate('customer', 'name email phone').sort('-createdAt').skip(skip).limit(limit),
    Order.countDocuments(filter),
  ]);
  res.json({ success: true, data, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
});

export const adminUpdateStatus = asyncHandler(async (req, res) => {
  const order = await Order.findById(req.params.id);
  if (!order) throw new ApiError(404, 'Order not found');
  const next = req.body.status;
  if (!STATUS_TRANSITIONS[order.orderStatus].includes(next))
    throw new ApiError(400, `Cannot change status from "${order.orderStatus}" to "${next}"`);
  order.orderStatus = next;
  order.statusHistory.push({ status: next });
  if (next === 'Delivered') order.paymentStatus = 'Paid'; // COD collected on delivery
  await order.save();
  res.json({ success: true, data: order });
});
