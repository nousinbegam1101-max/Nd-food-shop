export const notFound = (req, res) =>
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });

export function errorHandler(err, _req, res, _next) {
  let status = err.status || 500;
  let message = err.message;
  if (err.name === 'ValidationError') { status = 400; message = Object.values(err.errors)[0].message; }
  else if (err.name === 'CastError') { status = 400; message = 'Invalid ID or value'; }
  else if (err.code === 11000) { status = 409; message = 'A record with that value already exists'; }
  if (status >= 500) {
    console.error(err.name, err.message);
    if (process.env.NODE_ENV === 'production') message = 'Something went wrong';
  }
  const body = { success: false, message };
  if (err.details) body.errors = err.details;
  if (status >= 500 && process.env.NODE_ENV !== 'production') body.stack = err.stack;
  res.status(status).json(body);
}
