import { validationResult, param } from 'express-validator';

export function validate(req, res, next) {
  const result = validationResult(req);
  if (result.isEmpty()) return next();
  const errors = result.array().map((e) => ({ field: e.path, message: e.msg }));
  return res.status(400).json({ success: false, message: errors[0].message, errors });
}
export const validateId = (name = 'id') => [param(name).isMongoId().withMessage('Invalid ID'), validate];
