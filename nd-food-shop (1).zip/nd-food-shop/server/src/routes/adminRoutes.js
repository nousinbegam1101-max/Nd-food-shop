import { Router } from 'express';
import { body } from 'express-validator';
import { dashboard, listCustomers, customerOrders } from '../controllers/adminController.js';
import { adminListOrders, adminUpdateStatus, getOrder } from '../controllers/orderController.js';
import { protect, adminOnly } from '../middleware/auth.js';
import { validate, validateId } from '../middleware/validate.js';
import { ORDER_STATUSES } from '../models/Order.js';

const router = Router();
router.use(protect, adminOnly);
router.get('/dashboard', dashboard);
router.get('/customers', listCustomers);
router.get('/customers/:id/orders', validateId(), customerOrders);
router.get('/orders', adminListOrders);
router.get('/orders/:id', validateId(), getOrder);
router.patch('/orders/:id/status', validateId(), [body('status').isIn(ORDER_STATUSES).withMessage('Invalid status'), validate], adminUpdateStatus);
export default router;
