import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { body } from 'express-validator';
import { register, login, me, logout, updateProfile, changePassword } from '../controllers/authController.js';
import { protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';

const router = Router();
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: process.env.NODE_ENV === 'test' ? 1000 : 20,
  standardHeaders: true, legacyHeaders: false,
  message: { success: false, message: 'Too many attempts. Try again later.' },
});

const email = body('email').isEmail().withMessage('Valid email is required').normalizeEmail();
const password = body('password').isLength({ min: 8, max: 72 }).withMessage('Password must be 8-72 characters');

router.post('/register', limiter, [
  body('name').trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  email,
  body('phone').trim().matches(/^[+]?[0-9\s-]{10,15}$/).withMessage('Valid phone number is required'),
  password, validate,
], register);
router.post('/login', limiter, [email, body('password').notEmpty().withMessage('Password is required'), validate], login);
router.get('/me', protect, me);
router.post('/logout', logout);
router.put('/profile', protect, [
  body('name').optional().trim().isLength({ min: 2, max: 80 }).withMessage('Name must be 2-80 characters'),
  body('phone').optional().trim().matches(/^[+]?[0-9\s-]{10,15}$/).withMessage('Valid phone number is required'),
  validate,
], updateProfile);
router.put('/password', protect, limiter, [
  body('currentPassword').notEmpty().withMessage('Current password is required'),
  body('newPassword').isLength({ min: 8, max: 72 }).withMessage('New password must be 8-72 characters'),
  validate,
], changePassword);

export default router;
