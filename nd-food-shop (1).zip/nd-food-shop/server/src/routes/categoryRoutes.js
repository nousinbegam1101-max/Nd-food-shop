import { Router } from 'express';
import { body } from 'express-validator';
import { listCategories, createCategory, updateCategory, deleteCategory } from '../controllers/categoryController.js';
import { protect, adminOnly } from '../middleware/auth.js';
import { validate, validateId } from '../middleware/validate.js';

const router = Router();
const rules = [body('name').trim().isLength({ min: 2, max: 60 }).withMessage('Name must be 2-60 characters'), validate];
router.get('/', listCategories);
router.post('/', protect, adminOnly, rules, createCategory);
router.put('/:id', protect, adminOnly, validateId(), rules, updateCategory);
router.delete('/:id', protect, adminOnly, validateId(), deleteCategory);
export default router;
