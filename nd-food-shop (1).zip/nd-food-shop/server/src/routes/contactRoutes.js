import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { body } from 'express-validator';
import ContactMessage from '../models/ContactMessage.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { validate } from '../middleware/validate.js';

const router = Router();
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: process.env.NODE_ENV === 'test' ? 1000 : 10, message: { success: false, message: 'Too many messages. Try later.' } });
router.post('/', limiter, [
  body('name').trim().isLength({ min: 2, max: 80 }).withMessage('Name is required'),
  body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('subject').trim().isLength({ min: 3, max: 120 }).withMessage('Subject is required'),
  body('message').trim().isLength({ min: 10, max: 2000 }).withMessage('Message must be 10-2000 characters'),
  validate,
], asyncHandler(async (req, res) => {
  const { name, email, subject, message } = req.body;
  await ContactMessage.create({ name, email, subject, message });
  res.status(201).json({ success: true, message: 'Thanks! Your message has been received.' });
}));
export default router;
