import { Router } from 'express';
import { body } from 'express-validator';
import { listFoods, getFood, createFood, updateFood, deleteFood } from '../controllers/foodController.js';
import { protect, adminOnly } from '../middleware/auth.js';
import { validate, validateId } from '../middleware/validate.js';

const router = Router();
const rules = (req) => [
  body('name')[req ? 'exists' : 'optional']().trim().isLength({ min: 2, max: 100 }).withMessage('Name must be 2-100 characters'),
  body('price')[req ? 'exists' : 'optional']().isFloat({ min: 0, max: 100000 }).withMessage('Price must be a positive number').toFloat(),
  body('category')[req ? 'exists' : 'optional']().isMongoId().withMessage('Valid category is required'),
  body('image').optional({ values: 'falsy' }).isURL({ protocols: ['http', 'https'] }).withMessage('Image must be an http(s) URL'),
  validate,
];
router.get('/', listFoods);
router.get('/:id', validateId(), getFood);
router.post('/', protect, adminOnly, rules(true), createFood);
router.put('/:id', protect, adminOnly, validateId(), rules(false), updateFood);
router.delete('/:id', protect, adminOnly, validateId(), deleteFood);
export default router;
