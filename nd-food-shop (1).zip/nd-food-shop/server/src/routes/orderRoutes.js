import { Router } from 'express';
import { body } from 'express-validator';
import { createOrder, myOrders, getOrder, cancelOrder } from '../controllers/orderController.js';
import { protect } from '../middleware/auth.js';
import { validate, validateId } from '../middleware/validate.js';

const router = Router();
router.use(protect);
router.post('/', [
  body('items').isArray({ min: 1, max: 50 }).withMessage('Cart is empty'),
  body('items.*.food').isMongoId().withMessage('Invalid food item'),
  body('items.*.quantity').isInt({ min: 1, max: 50 }).withMessage('Quantity must be 1-50').toInt(),
  body('deliveryAddress.line1').trim().notEmpty().withMessage('Delivery address is required'),
  body('deliveryAddress.city').trim().notEmpty().withMessage('City is required'),
  body('deliveryAddress.postalCode').trim().matches(/^[0-9A-Za-z\s-]{4,10}$/).withMessage('Valid postal code is required'),
  body('phone').trim().matches(/^[+]?[0-9\s-]{10,15}$/).withMessage('Valid phone number is required'),
  body('deliveryInstructions').optional().isLength({ max: 300 }).withMessage('Instructions too long'),
  body('paymentMethod').optional().equals('COD').withMessage('Only Cash on Delivery is available'),
  validate,
], createOrder);
router.get('/my-orders', myOrders);
router.get('/:id', validateId(), getOrder);
router.patch('/:id/cancel', validateId(), cancelOrder);
export default router;
