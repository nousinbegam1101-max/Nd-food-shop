import 'dotenv/config';
import mongoose from 'mongoose';
import User from '../models/User.js';

// Usage: set ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD in server/.env, then: npm run create-admin
const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD, MONGO_URI } = process.env;
if (!ADMIN_NAME || !ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 10) {
  console.error('Set ADMIN_NAME, ADMIN_EMAIL and ADMIN_PASSWORD (10+ chars) in server/.env');
  process.exit(1);
}
await mongoose.connect(MONGO_URI);
const email = ADMIN_EMAIL.toLowerCase();
const existing = await User.findOne({ email });
if (existing) { existing.role = 'admin'; await existing.save(); console.log(`Existing user ${email} promoted to admin.`); }
else {
  await User.create({ name: ADMIN_NAME, email, phone: '0000000000', passwordHash: await User.hashPassword(ADMIN_PASSWORD), role: 'admin' });
  console.log(`Admin ${email} created.`);
}
console.log('Remove ADMIN_PASSWORD from .env now.');
await mongoose.disconnect();
