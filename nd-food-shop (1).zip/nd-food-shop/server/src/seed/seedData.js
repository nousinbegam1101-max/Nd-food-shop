import 'dotenv/config';
import mongoose from 'mongoose';
import Category from '../models/Category.js';
import Food from '../models/Food.js';

// Images are left blank: the client shows a placeholder. Admins can add image URLs in the dashboard.
const cats = ['South Indian', 'North Indian', 'Rice and Biryani', 'Snacks', 'Beverages'];
const foods = [
  ['Idli (3 pcs)', 'Soft steamed rice cakes with sambar and chutney', 40, 0, true, true],
  ['Dosa', 'Crispy golden dosa with chutney and sambar', 60, 0, true, true],
  ['Masala Dosa', 'Dosa stuffed with spiced potato masala', 80, 0, true, true],
  ['Pongal', 'Creamy rice and lentil dish tempered with pepper and ghee', 70, 0, true, false],
  ['Poori (2 pcs)', 'Fluffy fried bread served with potato masala', 65, 0, true, false],
  ['Veg Meals', 'Rice, sambar, rasam, two kootu/poriyal, curd and papad', 120, 0, true, true],
  ['Parotta (2 pcs)', 'Flaky layered flatbread with salna', 60, 0, true, false],
  ['Chapati (2 pcs)', 'Soft whole-wheat chapati with veg kurma', 55, 1, true, false],
  ['Chicken Biryani', 'Aromatic basmati rice cooked with spiced chicken', 180, 2, false, true],
  ['Veg Fried Rice', 'Wok-tossed rice with fresh vegetables', 110, 2, true, false],
  ['Chicken Fried Rice', 'Wok-tossed rice with chicken and egg', 140, 2, false, false],
  ['Samosa (2 pcs)', 'Crispy pastry filled with spiced potatoes and peas', 30, 3, true, true],
  ['Fresh Lime Juice', 'Freshly squeezed lime, sweet or salt', 35, 4, true, false],
  ['Tea', 'Hot masala chai', 15, 4, true, false],
  ['Coffee', 'Filter coffee, strong and frothy', 20, 4, true, false],
];
await mongoose.connect(process.env.MONGO_URI);
await Promise.all([Category.deleteMany({}), Food.deleteMany({})]);
const created = await Category.insertMany(cats.map((name) => ({ name, description: `${name} favourites` })));
await Food.insertMany(foods.map(([name, description, price, c, isVegetarian, isPopular]) =>
  ({ name, description, price, category: created[c]._id, isVegetarian, isPopular, isAvailable: true })));
console.log(`Seeded ${created.length} categories and ${foods.length} foods.`);
await mongoose.disconnect();
