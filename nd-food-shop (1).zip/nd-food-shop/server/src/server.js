import 'dotenv/config';
import app from './app.js';
import { connectDB } from './config/db.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 16) {
  console.error('Set a JWT_SECRET (16+ chars) in server/.env');
  process.exit(1);
}
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`API on http://localhost:${port}`));
connectDB().catch((e) => console.error('MongoDB connection failed:', e.message, '- API returns 503 until it is available.'));
