import jwt from 'jsonwebtoken';

export const COOKIE_NAME = 'ndfs_token';
const opts = () => ({
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  path: '/',
});

export function sendToken(res, user) {
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
  res.cookie(COOKIE_NAME, token, { ...opts(), maxAge: 7 * 24 * 60 * 60 * 1000 });
}
export const clearToken = (res) => res.clearCookie(COOKIE_NAME, opts());
